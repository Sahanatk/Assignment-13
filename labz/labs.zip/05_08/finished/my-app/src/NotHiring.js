import React from 'react'

export const NotHiring = () =>
    <div>
        <p>The Library is not hiring. Check back again.</p>
    </div>